﻿using System;

namespace MusicJuke.Entities
{
    public interface IGUser
    {
        string Address { get; set; }
        bool adminbit { get; set; }
        string City { get; set; }
        DateTime DOB { get; set; }
        long Mobile { get; set; }
        string Name { get; set; }
        string Password { get; set; }
        string UserName { get; set; }
    }
}