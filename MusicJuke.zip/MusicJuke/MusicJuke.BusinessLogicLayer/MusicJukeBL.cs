﻿using MusicJuke.DataAccessLayer;
using MusicJuke.Entities;
using MusicJuke.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicJuke.BusinessLogicLayer
{
    public class MusicJukeBL
    {
        MusicJukeDAL dl = new MusicJukeDAL();
        public bool Validate(IGUser user)
        {
            try
            {
                bool returnVal = true;
                if (user.UserName == null || user.UserName == " ")
                    returnVal = false;
                else if (user.Password == null || user.Password == " ")
                    returnVal = false;
                else if (user.Name == null || user.Name == " ")
                    returnVal = false;
                else if (user.Address == null || user.Address == " ")
                    returnVal = false;
                else if (user.City == null || user.City == " ")
                    returnVal = false;
                else if (user.Mobile > 9999999999 || user.Mobile < 7000000000)
                    returnVal = false;
                return returnVal;
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public bool Register(IGUser gUser)
        {
            try
            {
                if (Validate(gUser))
                    return dl.Register(gUser);
                return false;
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public IGUser LogIn(string username, string password)
        {
            try
            {
                return dl.LogIn(username, password);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public Album ViewAlbumByID(int albumID)
        {
            try
            {
                return dl.ViewAlbumByID(albumID);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public Song ViewSongByID(int songID)
        {
            try
            {
                return dl.ViewSongByID(songID);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public DataTable SearchByAlbumName(string albumname)
        {
            try
            {
                return dl.SearchByAlbumName(albumname);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public DataTable SearchBySongName(string songname)
        {
            try
            {
                return dl.SearchBySongName(songname);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public DataTable SearchBySinger(string singer)
        {
            try
            {
                return dl.SearchBySinger(singer);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public void Download(string songname, string link)
        {
            try
            {
                dl.Download(songname, link);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public DataTable SearchUser(int userid)
        {
            try
            {
                return dl.SearchUser(userid);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public bool DeleteAlbum(int albumid)
        {
            try
            {
                return dl.DeleteAlbum(albumid);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public bool UpdateAlbum(Album album)
        {
            try
            {
                return dl.UpdateAlbum(album);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public bool DeleteUser(int userid)
        {
            try
            {
                return dl.DeleteUser(userid);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public bool RemoveMusic(int songid)
        {
            try
            {
                return dl.RemoveMusic(songid);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public bool UploadMusic(Song song)
        {
            try
            {
                return dl.UploadMusic(song);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
        public bool DeleteAlbumIdFromSong(int songid)
        {
            try
            {
                return dl.DeleteAlbumIdFromSong(songid);
            }
            catch (MusicJukeException)
            {

                throw;
            }
        }
    }
}
