﻿using MusicJuke.Entities;
using MusicJuke.Exceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MusicJuke.DataAccessLayer
{
    public class MusicJukeDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr1"].ConnectionString);
        SqlCommand cmd = new SqlCommand();
        public bool Register(IGUser gUser)
        {
            try
            {
                cmd.CommandText = "Music_Box.usp_Common_Register";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                cmd.Parameters.Add("@name", SqlDbType.VarChar, 200);
                cmd.Parameters["@name"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@username", SqlDbType.VarChar, 50);
                cmd.Parameters["@username"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@address", SqlDbType.VarChar, 250);
                cmd.Parameters["@address"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@dob", SqlDbType.Date);
                cmd.Parameters["@dob"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@city", SqlDbType.VarChar, 50);
                cmd.Parameters["@city"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@password", SqlDbType.VarChar, 50);
                cmd.Parameters["@password"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@mobile", SqlDbType.BigInt);
                cmd.Parameters["@mobile"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@admin", SqlDbType.Bit);
                cmd.Parameters["@admin"].Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();

                if (cmd.ExecuteNonQuery() > 0)
                    return true;
                return false;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public IGUser LogIn(string username, string password)
        {
            try
            {
                cmd.CommandText = "Music_Box.usp_Common_Login";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                cmd.Parameters.Add("@uid", SqlDbType.Int);
                cmd.Parameters["@uid"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@name", SqlDbType.VarChar, 200);
                cmd.Parameters["@name"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@admin", SqlDbType.Bit);
                cmd.Parameters["@admin"].Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                IGUser iguser = null;
                int? UID = Convert.ToInt32(cmd.Parameters["@uid"].Value);
                string name = cmd.Parameters["@name"].Value.ToString();
                bool admin = Convert.ToBoolean(cmd.Parameters["@admin"].Value);
                if (admin)
                    iguser = new Admin();
                else
                    iguser = new User();
                iguser.Name = name;
                iguser.adminbit = admin;

                return iguser;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public Album ViewAlbumByID(int albumID)
        {
            try
            {
                cmd.CommandText = "Music_Box.usp_Common_ViewAlbumByID";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                cmd.Parameters.AddWithValue("@albumid", albumID);
                cmd.Parameters.Add("@albumname", SqlDbType.VarChar, 50);
                cmd.Parameters["@albumname"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@category", SqlDbType.VarChar, 50);
                cmd.Parameters["@category"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@noofsongs", SqlDbType.Int);
                cmd.Parameters["@noofsongs"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@releasedate", SqlDbType.Date);
                cmd.Parameters["@releasedate"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@company", SqlDbType.VarChar, 50);
                cmd.Parameters["@company"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@price", SqlDbType.Money);
                cmd.Parameters["@price"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@language", SqlDbType.VarChar, 50);
                cmd.Parameters["@language"].Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                Album album = new Album()
                {
                    AlbumID = Convert.ToInt32(cmd.Parameters["@albumid"].Value),
                    AlbumName = cmd.Parameters["@albumname"].Value.ToString(),
                    Category = cmd.Parameters["@category"].Value.ToString(),
                    NoOfSongs = Convert.ToInt32(cmd.Parameters["@noofsongs"].Value),
                    ReleaseDate = Convert.ToDateTime(cmd.Parameters["@releasedate"].Value),
                    Company = cmd.Parameters["@company"].Value.ToString(),
                    Price = Convert.ToDecimal(cmd.Parameters["@price"].Value),
                    Language = cmd.Parameters["@language"].Value.ToString()
                };
                return album;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public Song ViewSongByID(int songID)
        {
            try
            {
                cmd.CommandText = "Music_Box.usp_Common_ViewSongByID";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                cmd.Parameters.AddWithValue("@songid", songID);
                cmd.Parameters.Add("@songname", SqlDbType.VarChar, 100);
                cmd.Parameters["@songname"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@singer", SqlDbType.VarChar, 100);
                cmd.Parameters["@singer"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@movie", SqlDbType.VarChar, 200);
                cmd.Parameters["@movie"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@composedBy", SqlDbType.VarChar, 100);
                cmd.Parameters["@composedBy"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@albumid", SqlDbType.Int);
                cmd.Parameters["@albumid"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@lyrics", SqlDbType.VarChar, 600);
                cmd.Parameters["@lyrics"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@year", SqlDbType.Int);
                cmd.Parameters["@year"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@language", SqlDbType.VarChar, 50);
                cmd.Parameters["@language"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@link", SqlDbType.VarChar, 300);
                cmd.Parameters["@link"].Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                con.Close();
                Song song = new Song()
                {
                    SongID = Convert.ToInt32(cmd.Parameters["@songid"].Value),
                    SongName = cmd.Parameters["@songname"].Value.ToString(),
                    Movie = cmd.Parameters["@movie"].Value.ToString(),
                    ComposedBy = cmd.Parameters["@composedby"].Value.ToString(),
                    AlbumID = Convert.ToInt32(cmd.Parameters["@albumid"].Value),
                    Lyrics = cmd.Parameters["@lyrics"].Value.ToString(),
                    Year = Convert.ToInt32(cmd.Parameters["@year"].Value),
                    Language = cmd.Parameters["@language"].Value.ToString(),
                    Link = cmd.Parameters["@link"].Value.ToString()
                };
                return song;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public DataTable SearchByAlbumName(string albumname)
        {
            try
            {
                cmd.CommandText = "Music_Box.usp_Common_SearchByAlbumName";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@albumname", albumname);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = null;
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
                return dt;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public DataTable SearchBySongName(string songname)
        {
            try
            {
                cmd.CommandText = "Music_Box.usp_Common_SearchBySongName";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@songname", songname);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = null;
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
                return dt;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public DataTable SearchBySinger(string singer)
        {
            try
            {
                cmd.CommandText = "Music_Box.usp_Common_SearchBySinger";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@singer", singer);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = null;
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
                return dt;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public void Download(string songname, string link)
        {
            try
            {
                using (var client = new WebClient())
                {
                    client.DownloadFile(link, songname + ".mp3");
                }
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }
        public DataTable SearchUser(int userid)
        {
            try
            {
                cmd = new SqlCommand("Music_Box.usp_SearchUser", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@userid", userid);
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = null;
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
                return dt;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool DeleteAlbum(int albumid)
        {
            try
            {
                cmd = new SqlCommand("Music_Box.usp_DeleteAlbum", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@albumid", albumid);
                con.Open();
                bool delete = (cmd.ExecuteNonQuery() > 0);
                return delete;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool UpdateAlbum(Album album)
        {
            try
            {
                cmd = new SqlCommand("Music_Box.usp_UpdateAlbum", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@albumid", album.AlbumID);
                cmd.Parameters.AddWithValue("@albumname", album.AlbumName);
                cmd.Parameters.AddWithValue("@category", album.Category);
                cmd.Parameters.AddWithValue("@noofsongs", album.NoOfSongs);
                cmd.Parameters.AddWithValue("@releasedate", album.ReleaseDate);
                cmd.Parameters.AddWithValue("@company", album.Company);
                cmd.Parameters.AddWithValue("@price", album.Price);
                cmd.Parameters.AddWithValue("@language", album.Language);
                con.Open();
                bool update = (cmd.ExecuteNonQuery() > 0);
                return update;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool DeleteUser(int id)
        {
            try
            {
                cmd = new SqlCommand("Music_Box.usp_DeleteUser", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@userid", id);
                con.Open();
                bool delete = (cmd.ExecuteNonQuery() > 0);
                return delete;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool RemoveMusic(int songid)
        {
            try
            {
                cmd = new SqlCommand("Music_Box.usp_RemoveMusic", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@songid", songid);
                con.Open();
                bool delete = (cmd.ExecuteNonQuery() > 0);
                return delete;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool UploadMusic(Song song)
        {
            try
            {
                cmd = new SqlCommand("Music_Box.usp_DeleteUser", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@songname", song.SongID);
                cmd.Parameters.AddWithValue("@singer", song.SongName);
                cmd.Parameters.AddWithValue("@movie", song.Movie);
                cmd.Parameters.AddWithValue("@composedBy", song.ComposedBy);
                cmd.Parameters.AddWithValue("@albumid", song.AlbumID);
                cmd.Parameters.AddWithValue("@lyrics", song.Lyrics);
                cmd.Parameters.AddWithValue("@year", song.Year);
                cmd.Parameters.AddWithValue("@language", song.Language);
                cmd.Parameters.AddWithValue("@link", song.Link);
                con.Open();
                bool upload = (cmd.ExecuteNonQuery() > 0);
                return upload;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool DeleteAlbumIdFromSong(int songid)
        {
            try
            {
                cmd = new SqlCommand("Music_Box.usp_RemoveMusic", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@songid", songid);
                con.Open();
                bool delete = (cmd.ExecuteNonQuery() > 0);
                return delete;
            }
            catch (MusicJukeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
    }
}
