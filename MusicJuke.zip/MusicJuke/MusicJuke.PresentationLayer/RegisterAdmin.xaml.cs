﻿using MusicJuke.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MusicJuke.PresentationLayer
{
    /// <summary>
    /// Interaction logic for RegisterUser.xaml
    /// </summary>
    public partial class RegisterAdmin : Window
    {
        public RegisterAdmin()
        {
            InitializeComponent();
        }

        private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
            catch (MusicJukeException ex)
            {
                MessageBox.Show(ex.Message, "Music Juke Box");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Music Juke Box");
            }
        }

        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                Close();
            }
            catch (MusicJukeException ex)
            {
                MessageBox.Show(ex.Message, "Music Juke Box");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Music Juke Box");
            }
        }
    }
}
