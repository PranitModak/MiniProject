﻿using MusicJuke.Entities;
using MusicJuke.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MusicJuke.BusinessLogicLayer;

namespace MusicJuke.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class Home : Window
    {
        public Home()
        {
            InitializeComponent();
            Player player = new Player();
            object tmp = player.Content;
            player.Content = null;
            CenterFrame.Content = new ContentControl() { Content = tmp };
        }
        
        public Home(IGUser user)
        {
            InitializeComponent();
            lblname.Content = user.Name;
            Player player = new Player();
            object tmp = player.Content;
            player.Content = null;
            CenterFrame.Content = new ContentControl() { Content = tmp };
        }

        private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
            catch (MusicJukeException ex)
            {
                MessageBox.Show(ex.Message, "Music Juke Box");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Music Juke Box");
            }
        }

        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                Application.Current.Shutdown();
            }
            catch (MusicJukeException ex)
            {
                MessageBox.Show(ex.Message, "Music Juke Box");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Music Juke Box");
            }
        }

        private void ImgAcc_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if(lblname.Content==null)
                {
                    Login main = new Login();
                    App.Current.MainWindow = main;
                    this.Close();
                    main.Show();
                }
            }
            catch (MusicJukeException ex)
            {
                MessageBox.Show(ex.Message, "Music Juke Box");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Music Juke Box");
            }
        }
    }
}
